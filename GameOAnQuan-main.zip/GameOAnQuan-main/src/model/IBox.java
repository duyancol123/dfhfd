package model;

public interface IBox {
	public int getNumberStone();

	public int getIndex();

	public void setNumberStone(int numberStone);
}
