package controller;

import view.Menu;

public class Test {
	public static void main(String[] args) {
		new Menu().setVisible(true);
	}
}
