package controller;

public interface Controller_Interface {
	public void move(int index, boolean direction, boolean turn);
}
