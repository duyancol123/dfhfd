package view;

public interface IStoneObserver {
	public void updateStone(int index,int stone);
}
