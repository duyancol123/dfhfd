package view;

public interface IDraw{
	
	public void draw(int index,boolean turn);

	public void reDraw(int index);
}
