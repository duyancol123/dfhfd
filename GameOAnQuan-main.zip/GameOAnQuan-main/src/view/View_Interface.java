package view;

public interface View_Interface {

	public void setVisible(boolean b);

	public void turnOver(boolean turn);

	public void turnOverComputer();

	void firstTurn(boolean turn);


}
