package view;

public interface IHelp {
	public void back();

	public void setVisible(boolean b);
}
