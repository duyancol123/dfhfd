package view;

import java.util.List;

import model.IPlayer;

public interface Interface_GameOver {
	public void addName(List<IPlayer> list);

	public void back();

	public void setVisible(boolean b);
}
