package view;

public interface IFrame {
	public static final int WIDTHJF = 905;
	public static final int HEIGHTJF = 610;

}
