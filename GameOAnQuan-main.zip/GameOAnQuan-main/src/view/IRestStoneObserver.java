package view;

public interface IRestStoneObserver {
	public void updateRestStone(int stone, boolean turn);
}
