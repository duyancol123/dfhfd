package view;

public interface INewGame {
	public void onePlayer();

	public void twoPlayer();

	public void back();

	public void setVisible(boolean b);
}
