package view;

public interface INumber_Player {
	public void newGame();

	public void back();

	public void setVisible(boolean b);
}
