package view;

public interface IHighScore {
	public void back();
	public void reset();
	public void setVisible(boolean b);
}
