package view;

public interface IScoreObserver {
	public void updateScore(int score,boolean turn);
}
