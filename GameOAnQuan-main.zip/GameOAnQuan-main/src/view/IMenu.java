package view;

public interface IMenu {
	public void newGame();

	public void highScore();

	public void help();

	public void setVisible(boolean b);
}
