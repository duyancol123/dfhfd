package view;

public enum Number_Player_Type {
	ONEPLAYER, TWOPLAYER;
}
