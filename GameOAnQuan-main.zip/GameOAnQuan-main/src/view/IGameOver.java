package view;

import java.util.List;

import model.IPlayer;

public interface IGameOver {
	public void gameOver(List<IPlayer> listPlayer);
}
