package AI;

public interface IEatBox_AI {
	public void eat(int index, boolean direction, boolean turn);

	public void recursiveEat(int index, boolean direction, boolean turn);
}
